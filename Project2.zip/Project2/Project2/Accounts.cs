﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project2
{
    public class Accounts
    {
        public string userName { get; set; }
        public string password { get; set; }

        public Accounts(string Name,string pass)
        {
            userName = Name;
            password = pass;

        }
        
        public List<Accounts> getAccounts()
        {
            Accounts Admin = new Accounts("admin", "admin");
            List<Accounts> Accounts = new List<Accounts>();
            Accounts.Add(Admin);
            return Accounts;
        }
    
    }

    
}