﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project2
{
    public class newItems
    {

        public int itemID { get; set; }
        public string itemName { get; set; }
        public int costPrice { get; set; }
        public int salePrice { get; set; }

        public newItems(int ID,string Name, int cost, int sale)
        {
            itemID = ID;
            itemName = Name;
            costPrice = cost;
            salePrice = sale;

        }

        
        public List<newItems> getItems()
        {
            newItems Bag = new newItems(34, "Bag", 89, 98);
            newItems Pencil = new newItems(145, "Pencil", 10, 20);
            newItems Pen = new newItems(169, "Pen", 20, 30);
            List<newItems> Items = new List<newItems>();
            Items.Add(Pencil);
            Items.Add(Pen);
            Items.Add(Bag);
            return Items;
        }
    }
}
   