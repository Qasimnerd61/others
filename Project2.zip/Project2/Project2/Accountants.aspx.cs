﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project2
{
    public partial class Accountants : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["user"]!="admin")
            {
                Response.Redirect("MainPage.aspx");
            }
            
          
        }

        protected void LogOut_btn_Click(object sender, EventArgs e)
        {
            Session["user"] = null;
            Response.Redirect("Login.aspx");
        }

        protected void Add_btn_Click(object sender, EventArgs e)
        {
            string userName=username.Text;
            string pass=password.Text;
            Accounts account=new Accounts(userName,pass);
            List<Accounts> list = (List<Accounts>)Session["accounts"];
            list.Add(account);
            Session["accounts"] = list;
            Status.Text = "Accountant Added!";
        }

      
    }
}