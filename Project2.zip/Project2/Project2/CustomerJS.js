﻿$(document).ready(function () {

    $.ajax({
        url: 'Customers.aspx/GetCustomers',
        method: 'post',
        dataType: 'json',
        contentType: 'application/json',
        async: false,
        success: function (data) {

            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'ID' },
                    { 'data': 'Name' },
                    { 'data': 'Address' },
                    {
                        'data': 'ID',
                        'render': function (data) {
                            return '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="editCustomer(' + data + ')"><i class="fa fa-pencil"></i></button> <button type="button" class="btn btn-primary" id="deleteItem" onclick="clearCustomer(' + data + ')"><i class="fa fa-trash"></i></button>'
                        }
                    }
                ]
            });
        }

    });
});

function editCustomer(id) {


    var inputName = document.createElement("input");
    inputName.setAttribute("type", "text");
    inputName.setAttribute("id", "inputName");

    var inputAddress = document.createElement("input");
    inputAddress.setAttribute("type", "text");
    inputAddress.setAttribute("id", "inputAddress");


    for (let i = 0; i < myTable.rows.length; i++) {

        var x = document.getElementById("myTable").rows[i].cells[0].innerHTML;
        if (id == x) {

            var placeName = document.getElementById("myTable").rows[i].cells[1].innerHTML;
            inputName.setAttribute("placeholder", placeName);

            var placeAddress = document.getElementById("myTable").rows[i].cells[2].innerHTML;
            inputAddress.setAttribute("placeholder", placeAddress);

            document.getElementById("myTable").rows[i].cells[1].innerHTML = "";
            document.getElementById("myTable").rows[i].cells[1].appendChild(inputName);

            document.getElementById("myTable").rows[i].cells[2].innerHTML = "";
            document.getElementById("myTable").rows[i].cells[2].appendChild(inputAddress);

            document.getElementById("myTable").rows[i].cells[3].innerHTML = "";
            var y2 = '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="updateCustomer(' + x + ')">Update</button> <button class="btn btn-primary" id="cancel" >Cancel</button>'
            document.getElementById("myTable").rows[i].cells[3].innerHTML = y2;

            break;
        }

    }

}

function updateCustomer(id)
{
    var name = document.getElementById("inputName").value;
    var address = document.getElementById("inputAddress").value;
    
    $.ajax({
        url: 'Customers.aspx/EditCustomers',
        method: 'post',
        dataType: 'json',
        data: JSON.stringify({"id":id,"name":name,"address":address}),
        contentType: 'application/json',
        async: false,
        success: function (data) {
            var table = $('#myTable').DataTable();
            table.destroy();
            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'ID' },
                    { 'data': 'Name' },
                    { 'data': 'Address' },
                    {
                        'data': 'ID',
                        'render': function (data) {
                            return '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="editCustomer(' + data + ')"><i class="fa fa-pencil"></i></button> <button type="button" class="btn btn-primary" id="deleteItem" onclick="clearCustomer(' + data + ')"><i class="fa fa-trash"></i></button>'
                        }
                    }
                ]
            });
        }

    });
}
function clearCustomer(id) {

    for (let i = 0; i < myTable.rows.length; i++) {

        var x = document.getElementById("myTable").rows[i].cells[0].innerHTML;
        if (id == x) {



            document.getElementById("myTable").rows[i].cells[3].innerHTML = "";
            var y2 = '<h6 style="margin-bottom:0">Delete?<h6><br/><button type="button" class="btn btn-primary" id="editAccountantID" onclick="ClearCustomer(' + x + ')">Yes</button> <button class="btn btn-primary" id="cancel" >No</button>'
            document.getElementById("myTable").rows[i].cells[3].innerHTML = y2;

            break;
        }
    }
}
function ClearCustomer(id) {
    $.ajax({
        url: 'Customers.aspx/ClearCustomer',
        type: 'post',
        data: JSON.stringify({ "id": id }),
        contentType: 'application/json',
        async: false,
        success: function (data) {
            debugger
            var table = $('#myTable').DataTable();
            table.destroy();
            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'ID' },
                    { 'data': 'Name' },
                    { 'data': 'Address' },
                    {
                        'data': 'ID',
                        'render': function (data) {
                            return '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="editCustomer(' + data + ')"><i class="fa fa-pencil"></i></button> <button type="button" class="btn btn-primary" id="deleteItem" onclick="clearCustomer(' + data + ')"><i class="fa fa-trash"></i></button>'
                        }
                    }
                ]
            });


        }

    });

}
function displayDiv() {

    $("#addItem").fadeIn();

}
function hideDiv() {
    $("#addItem").fadeOut();
}
function addCustomer() {
    var ID = document.getElementById("newID").value;
    var name = document.getElementById("newName").value;
    var address = document.getElementById("newAddress").value;
    $.ajax({
        url: 'Customers.aspx/AddCustomer',
        method: 'post',
        dataType: 'json',
        data: JSON.stringify({ "id": ID, "name": name, "address": address }),
        contentType: 'application/json',
        async: false,
        success: function (data) {
            var table = $('#myTable').DataTable();
            table.destroy();
            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'ID' },
                    { 'data': 'Name' },
                    { 'data': 'Address' },
                    {
                        'data': 'ID',
                        'render': function (data) {
                            return '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="editCustomer(' + data + ')"><i class="fa fa-pencil"></i></button> <button type="button" class="btn btn-primary" id="deleteItem" onclick="clearCustomer(' + data + ')"><i class="fa fa-trash"></i></button>'
                        }
                    }
                ]
            });

            $("#status").html("Customer Added!")
        }

    });
}