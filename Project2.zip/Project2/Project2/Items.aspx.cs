﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project2
{
    public partial class Items : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            //if (!IsPostBack)
            //{
            //    if (Session["itemStart"] == null)
            //    {
            //        newItems session = new newItems(0,"",0,0);

            //        Session["items"] = session.getItems();

            //        Session["itemStart"] = "yes";
            //    }

            //}
        }

        [WebMethod]

        public static string GetItems()
        {
            List<newItems> list = (List<newItems>)HttpContext.Current.Session["items"];

            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(list);
        }
         [WebMethod]
        public static string UpdatedItems(string iD, string name, string cost,string sale)
        {
            List<newItems> list = (List<newItems>)HttpContext.Current.Session["items"];
            int ID = Convert.ToInt32(iD);
            
            for (int i = 0; i < list.Count; i++)
            {
                if (ID == list[i].itemID)
                {
                    if (name != "")
                    {
                        list[i].itemName = name;
                    }
                    if (cost !="")
                    {
                        list[i].costPrice = Convert.ToInt32(cost);
                    }
                    if (sale !="")
                    {
                        list[i].salePrice = Convert.ToInt32(sale);
                    }

                }
            }
            JavaScriptSerializer js1 = new JavaScriptSerializer();
            HttpContext.Current.Session["items"] = list;
            return js1.Serialize(list);
        }

        protected void LogOut_btn_Click(object sender, EventArgs e)
        {
            Session["user"] = null;
            Response.Redirect("Login.aspx");
        }

        [WebMethod]
        public static string AddItems(string iD, string name, string cost, string sale)
        {
            List<newItems> list = (List<newItems>)HttpContext.Current.Session["items"];
            int ID = Convert.ToInt32(iD);
            int Cost=Convert.ToInt32(cost);
            int Sale=Convert.ToInt32(sale);

            newItems newItem = new newItems(ID, name, Cost, Sale);
            list.Add(newItem);
            JavaScriptSerializer js2 = new JavaScriptSerializer();
            HttpContext.Current.Session["items"] = list;
            return js2.Serialize(list);
        }
        [WebMethod]
        public static string DeleteItems(string iD)
        {
            List<newItems> list = (List<newItems>)HttpContext.Current.Session["items"];
            int ID = Convert.ToInt32(iD);


            for (int i = 0; i < list.Count;i++)
            {
                if(ID==list[i].itemID)
                {
                    list.Remove(list[i]);
                }
            }
                
            JavaScriptSerializer js3 = new JavaScriptSerializer();
            HttpContext.Current.Session["items"] = list;
            return js3.Serialize(list);
        }

        
    }
}