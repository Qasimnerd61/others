﻿$(document).ready(function () {

    $.ajax({
        url: 'Bills.aspx/GetCustomers',
        method: 'post',
        dataType: 'json',
        contentType: 'application/json',
        async: false,
        success: function (data) {
            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'ID' },
                    { 'data': 'customerName' },
                    {
                        'data': 'items',
                        'render': function (items,type,full,meta)
                        {
                            debugger
                            var text = "";
                            for(let i=0;i<items.length;i++)
                            {
                                text += "<li>" + items[i].itemName + "</li>";
                            }
                            return ("<ol>"+text+"</ol>");
                        }
                    },
                    {
                        'data': 'items',
                        'render': function (items, type, full, meta) {
                            debugger
                            var sum = 0;
                            for (let i = 0; i < items.length; i++) {
                                sum +=  items[i].salePrice ;
                            }
                            return (sum);
                        }
                    },
                    { 'data': 'date' },
                    {
                        'data': 'ID',
                        'render': function (data) {
                            return '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="editBill(' + data + ')"><i class="fa fa-pencil"></i></button> <button type="button" class="btn btn-primary" id="deleteItem" onclick="ClearBill(' + data + ')"><i class="fa fa-trash"></i></button> <button type="button" class="btn btn-primary" id="editItem" onclick="ChangeItem(' + data + ')">Edit List</button>'
                        }
                    }
                ]
            });
        }
    });
});

function ClearBill(id)
{
    for (let i = 0; i < myTable.rows.length; i++) {

        var x = document.getElementById("myTable").rows[i].cells[0].innerHTML;
        if (id == x) {

            document.getElementById("myTable").rows[i].cells[5].innerHTML = "";
            var y2 = '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="ClearedBill(' + x + ')">Ok</button> <button class="btn btn-primary" id="cancel" >Cancel</button>'
            document.getElementById("myTable").rows[i].cells[5].innerHTML = y2;

            break;
        }

    }
}

function ClearedBill(id)
{
    $.ajax({
        url: 'Bills.aspx/ClearedBill',
        method: 'post',
        dataType: 'json',
        data: JSON.stringify({ "id": id }),
        contentType: 'application/json',
        async: false,
        success: function (data) {
            var table = $('#myTable').DataTable();
            table.destroy();
            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'ID' },
                    { 'data': 'customerName' },
                    {
                        'data': 'items',
                        'render': function (items, type, full, meta) {
                            debugger
                            var text = "";
                            for (let i = 0; i < items.length; i++) {
                                text += "<li>" + items[i].itemName + "</li>";
                            }
                            return ("<ol>" + text + "</ol>");
                        }
                    },
                    {
                        'data': 'items',
                        'render': function (items, type, full, meta) {
                            debugger
                            var sum = 0;
                            for (let i = 0; i < items.length; i++) {
                                sum += items[i].salePrice;
                            }
                            return (sum);
                        }
                    },
                    { 'data': 'date' },
                    {
                        'data': 'ID',
                        'render': function (data) {
                            return '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="editBill(' + data + ')"><i class="fa fa-pencil"></i></button> <button type="button" class="btn btn-primary" id="deleteItem" onclick="ClearBill(' + data + ')"><i class="fa fa-trash"></i></button> <button type="button" class="btn btn-primary" id="editItem" onclick="ChangeItem(' + data + ')">Edit List</button>'
                        }
                    }
                ]
            });

        }
    });
}

function editBill(id)
{
    let inputName = document.createElement("input");
    inputName.setAttribute("type", "text");
    inputName.setAttribute("id", "customerName");
    

    let inputDate = document.createElement("input");
    inputDate.setAttribute("type", "date");
    inputDate.setAttribute("id", "inputDate");


    for (let i = 0; i < myTable.rows.length; i++) {

        var x = document.getElementById("myTable").rows[i].cells[0].innerHTML;
        if (id == x) {

            var placeName = document.getElementById("myTable").rows[i].cells[1].innerHTML;
            inputName.setAttribute("placeholder", placeName);

            
            document.getElementById("myTable").rows[i].cells[1].innerHTML = "";
            document.getElementById("myTable").rows[i].cells[1].appendChild(inputName);
            
            document.getElementById("myTable").rows[i].cells[4].innerHTML = "";
            document.getElementById("myTable").rows[i].cells[4].appendChild(inputDate);

            document.getElementById("myTable").rows[i].cells[5].innerHTML = "";
            var y2 = '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="UpdateBill(' + x + ')">Update</button> <button class="btn btn-primary" id="cancel" >Cancel</button>'
            document.getElementById("myTable").rows[i].cells[5].innerHTML = y2;

            break;
        }

    }

}

function UpdateBill(id)
{
    var newName = document.getElementById("customerName").value;
    var newDate = document.getElementById("inputDate").value;
    $.ajax({
        url: 'Bills.aspx/UpdateInfo',
        method: 'post',
        dataType: 'json',
        data: JSON.stringify({ "id": id, "name": newName, "date":newDate }),
        contentType: 'application/json',
        async: false,
        success: function (data) {
            var table = $('#myTable').DataTable();
            table.destroy();
            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'ID' },
                    { 'data': 'customerName' },
                    {
                        'data': 'items',
                        'render': function (items, type, full, meta) {
                            debugger
                            var text = "";
                            for (let i = 0; i < items.length; i++) {
                                text += "<li>" + items[i].itemName + "</li>";
                            }
                            return ("<ol>" + text + "</ol>");
                        }
                    },
                    {
                        'data': 'items',
                        'render': function (items, type, full, meta) {
                            debugger
                            var sum = 0;
                            for (let i = 0; i < items.length; i++) {
                                sum += items[i].salePrice;
                            }
                            return (sum);
                        }
                    },
                    { 'data': 'date' },
                    {
                        'data': 'ID',
                        'render': function (data) {
                            return '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="editBill(' + data + ')"><i class="fa fa-pencil"></i></button> <button type="button" class="btn btn-primary" id="deleteItem" onclick="ClearBill(' + data + ')"><i class="fa fa-trash"></i></button> <button type="button" class="btn btn-primary" id="editItem" onclick="ChangeItem(' + data + ')">Edit List</button>'
                        }
                    }
                ]
            });

        }
    });
}

function ChangeItem(id)
{
    for (let i = 0; i < myTable.rows.length; i++) {

        var x = document.getElementById("myTable").rows[i].cells[0].innerHTML;
        if (id == x) {

            

            document.getElementById("myTable").rows[i].cells[5].innerHTML = "";
            var y2 = '<button type="button" class="btn btn-primary" onclick="addItem(' + x + ',' + 1 + ')">Add</button> <button type="button" class="btn btn-primary" onclick="addItem(' + x + ',' + 2 + ')">Delete</button> <button class="btn btn-primary" id="cancel" >Cancel</button>'
            document.getElementById("myTable").rows[i].cells[5].innerHTML = y2;

            break;
        }

    }
}
function addItem(id,choice) {
    let inputItem = document.createElement("input");
    inputItem.setAttribute("type", "text");
    inputItem.setAttribute("id", "writeItem");

    for (let i = 0; i < myTable.rows.length; i++) {

        var y = document.getElementById("myTable").rows[i].cells[0].innerHTML;
        if (id == y) {
            

            document.getElementById("myTable").rows[i].cells[2].innerHTML = "";
            document.getElementById("myTable").rows[i].cells[2].appendChild(inputItem);
            
            

            document.getElementById("myTable").rows[i].cells[5].innerHTML = "";
            var z = '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="UpdateItems(' + y + ','+choice+')">Ok</button> <button class="btn btn-primary" id="cancel" >Cancel</button>'
            document.getElementById("myTable").rows[i].cells[5].innerHTML = z;
        }
    }
}
function UpdateItems(id,choice)
{
    var newItem = document.getElementById("writeItem").value;
    var link;
    if (choice == 1)
    {
         link = 'Bills.aspx/AddItem';
    }
    else {
        link = 'Bills.aspx/ClearItem';
    }
    $.ajax({
        url: link,
        method: 'post',
        dataType: 'json',
        data: JSON.stringify({ "id": id, "name": newItem }),
        contentType: 'application/json',
        async: false,
        success: function (data) {
            var table = $('#myTable').DataTable();
            table.destroy();
            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'ID' },
                    { 'data': 'customerName' },
                    {
                        'data': 'items',
                        'render': function (items, type, full, meta) {
                            debugger
                            var text = "";
                            for (let i = 0; i < items.length; i++) {
                                text += "<li>" + items[i].itemName + "</li>";
                            }
                            return ("<ol>" + text + "</ol>");
                        }
                    },
                    {
                        'data': 'items',
                        'render': function (items, type, full, meta) {
                            debugger
                            var sum = 0;
                            for (let i = 0; i < items.length; i++) {
                                sum += items[i].salePrice;
                            }
                            return (sum);
                        }
                    },
                    { 'data': 'date' },
                    {
                        'data': 'ID',
                        'render': function (data) {
                            return '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="editBill(' + data + ')"><i class="fa fa-pencil"></i></button> <button type="button" class="btn btn-primary" id="deleteItem" onclick="ClearBill(' + data + ')"><i class="fa fa-trash"></i></button> <button type="button" class="btn btn-primary" id="editItem" onclick="ChangeItem(' + data + ')">Edit List</button>'
                        }
                    }
                ]
            });

        }
    });
}
var list=[];

    


function addNewItem() {
    var items = document.getElementById("newitems");
    list.push(items.value);
    items.value = "";
    document.getElementById("statusItem").innerHTML = "Item Added!";
}

function addBill()
{
    var newID = document.getElementById("newID").value;
    var newName = document.getElementById("newName").value;
    var newDate = document.getElementById("newDate").value;
    var newItems = list.toString();
    
    $.ajax({
        url: 'Bills.aspx/InsertBill',
        method: 'post',
        dataType: 'json',
        data: JSON.stringify({ "id": newID,"name":newName,"date":newDate ,"items":newItems }),
        contentType: 'application/json',
        async: false,
        success: function (data) {
            var table = $('#myTable').DataTable();
            table.destroy();
            $('#myTable').dataTable({
                data: JSON.parse(data.d),
                columns: [
                    { 'data': 'ID' },
                    { 'data': 'customerName' },
                    {
                        'data': 'items',
                        'render': function (items, type, full, meta) {
                            debugger
                            var text = "";
                            for (let i = 0; i < items.length; i++) {
                                text += "<li>" + items[i].itemName + "</li>";
                            }
                            return ("<ol>" + text + "</ol>");
                        }
                    },
                    {
                        'data': 'items',
                        'render': function (items, type, full, meta) {
                            debugger
                            var sum = 0;
                            for (let i = 0; i < items.length; i++) {
                                sum += items[i].salePrice;
                            }
                            return (sum);
                        }
                    },
                    { 'data': 'date' },
                    {
                        'data': 'ID',
                        'render': function (data) {
                            return '<button type="button" class="btn btn-primary" id="editAccountantID" onclick="editBill(' + data + ')"><i class="fa fa-pencil"></i></button> <button type="button" class="btn btn-primary" id="deleteItem" onclick="ClearBill(' + data + ')"><i class="fa fa-trash"></i></button> <button type="button" class="btn btn-primary" id="editItem" onclick="ChangeItem(' + data + ')">Edit List</button>'
                        }
                    }
                ]
            });
            $("#status").html("Bill Added!")
        }
    });

}
function showDiv() {

    $("#addBill").fadeIn();

}
function hideDiv() {
    $("#addBill").fadeOut();
}