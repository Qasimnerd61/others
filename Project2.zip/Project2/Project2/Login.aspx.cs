﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project2
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["page"] == null)
                {
                    Accounts accountSession = new Accounts(username.Text, password.Text);
                    Session["accounts"] = accountSession.getAccounts();
                   
                    Invoice billSession = new Invoice(0, null, "", "");
                    Session["Bill"] = billSession.GetInvoice();

                    Customer customerSession = new Customer(0, "", "");
                    Session["Customer"] = customerSession.getCustomers();

                    newItems itemSession = new newItems(0, "", 0, 0);
                    Session["items"] = itemSession.getItems();
                    
                    Session["page"] = "start";
                }
            }
            else
            {
                
            }
        }

        protected void submit_btn_Click(object sender, EventArgs e)
        {

            List<Accounts> Accounts = (List<Accounts>)Session["accounts"];
            int count = Accounts.Count() + 1;
            
            for(int i=0;i<Accounts.Count;i++)
            {
                
                if(username.Text==Accounts[i].userName && password.Text==Accounts[i].password)
                {
                    Session["user"]=Accounts[i].userName;
                    Response.Redirect("MainPage.aspx");
                    break;
                }
               
             
            }

            if(Session["user"]==null)
            {
                 
               Label_Error.Text = "No record found for this ID";
                
            }
            

        }
    }
}